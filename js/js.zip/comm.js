// JavaScript Document

function getCookie(objName){//获取指定名称的cookie的值 
	var arrStr = document.cookie.split("; "); 
	for(var i = 0;i < arrStr.length;i ++){
		var temp = arrStr[i].split("="); 
		if(temp[0] == objName)
			return unescape(temp[1]); 
	}
	return "";
}

function isLogin()
{
	if ( "" == getCookie( "auth" )
	|| "" == getCookie( "name" )
	|| "" == getCookie( "type" ) )
	{
		return false;
	}
	return true;
}

function checkLogin()
{
	if ( isLogin() )
	{
		return ;
	}
	
	window.location = "login.php?jump=" + window.location ;
}
